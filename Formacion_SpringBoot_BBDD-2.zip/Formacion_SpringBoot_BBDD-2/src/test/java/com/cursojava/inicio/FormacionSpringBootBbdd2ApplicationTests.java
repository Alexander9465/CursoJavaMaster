package com.cursojava.inicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormacionSpringBootBbdd2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
